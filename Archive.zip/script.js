let age = Number(prompt('Сколько вам лет'));
let up = 17;
let result = age + up;
console.log(`Через ${up} вам будет ${result}`);